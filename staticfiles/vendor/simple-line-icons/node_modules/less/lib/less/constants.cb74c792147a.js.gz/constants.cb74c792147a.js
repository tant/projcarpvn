"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RewriteUrls = exports.Math = void 0;
exports.Math = {
    ALWAYS: 0,
    PARENS_DIVISION: 1,
    PARENS: 2,
    STRICT_LEGACY: 3
};
exports.RewriteUrls = {
    OFF: 0,
    LOCAL: 1,
    ALL: 2
};
//# sourceMappingURL=constants.js.6b7f628d6794.map